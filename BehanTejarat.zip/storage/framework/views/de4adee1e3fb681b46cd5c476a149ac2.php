<?php $__env->startSection($title, 'title'); ?>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row no-gutters">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- Panel body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12">
                        
                        <table class="table text-center mt-5" dir="rtl">
                            <thead>
                            <tr>
                                
                                <th colspan="2" class="bg-info"> ریز جزئیات خروجی محصول <?php echo e($item->PName); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            
                            <tr class="text-center">
                                <th scope="col">تاریخ ثبت</th>
                                <td><?php echo e($item->TS); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">نام محصول</th>
                                <td><?php echo e($item->PName); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">نام تامین کننده</th>
                                <td><?php echo e($item->TName); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">تاریخ خروج محصول</th>
                                <td><?php echo e($item->date); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">قیمت خروجی</th>
                                <td dir="rtl"><?php echo e(number_format($item->exitPrice, 0, ".", ",")); ?> ريال </td>
                            </tr>
                            <tr>
                                <th scope="col">مقدار خروجی</th>
                                <td dir="rtl"><?php echo e(number_format($item->Count, 0, ".", ",")); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">قیمت کل خروجی</th>
                                <td dir="rtl"><?php echo e(number_format($item->TotalPrice, 0, ".", ",")); ?> ريال </td>
                            </tr>
                            <tr>
                                <th scope="col">قیمت کل انبار پس از خروج</th>
                                <td dir="rtl"><?php echo e(number_format($item->TotalPrice2, 0, ".", ",")); ?> ريال </td>
                            </tr>
                            <tr>
                                <th scope="col">موجودی کل انبار پس از خروج</th>
                                <td dir="rtl"><?php echo e(number_format($item->Count2, 0, ".", ",")); ?></td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger btn-block mb-2">بازگشت</a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/OutShow.blade.php ENDPATH**/ ?>