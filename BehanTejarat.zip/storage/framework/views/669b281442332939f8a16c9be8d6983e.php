<?php $__env->startSection($title,'title'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row no-gutters w-100">
            <div class="w-100">
                <div class="panel panel-primary w-100">
                    <div
                        class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                        <img src="<?php echo e(asset('assets/images/Indicator.png')); ?>" alt="ویرایش شاخص ها" class="img2">
                        <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                        <p>شما در این صفحه میتوانید شاخص ها را حذف،ویرایش و اضافه کنید. بدین منظور از دکمه های درون جدول
                            استفاده کنید.</p>
                    </div>
                    <span class="d-flex flex-column justify-content-center align-items-center">
                        <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2"><i class="material-icons">print</i></button>
                    <form action="<?php echo e(route('Admin.searchIndicator')); ?>" method="GET"
                          class="text-dark d-flex row justify-content-center align-items-center mb-4 search no-gutters">
                        <input type="text" name="search" class="text-dark date1" placeholder="جست و جو کنید">
                        <button type="submit"><i class="material-icons">search</i></button>
                    </form>
                        </span>
                    <!-- panel body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center" id="printdivcontent">
                        <table class="table text-center overflow-auto w-100" dir="rtl">
                            <thead>
                            <a href="<?php echo e(route('Admin.Links.create')); ?>" class="btn btn-block btn-info">لینک سازی جدید<i
                                    class="material-icons">add_circle_outline</i></a>
                            <?php if($items->isNotEmpty()): ?>
                            <tr>
                                <th scope="col">نام محصول</th>
                                <th scope="col">تاریخ ورودی</th>
                                <th scope="col">جزئیات لینک شده</th>
                                <th scope="col">شاخص سازی</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item -> PName); ?></td>
                                    <td><?php echo e($item -> date); ?></td>
                                    <td><a href="<?php echo e(route('Admin.Links.show', $item->id)); ?>" class="btn btn-info">
                                            <i class="material-icons">visibility</i>
                                        </a></td>
                                    <td><a href="<?php echo e(route('Admin.Indicator.edit', $item->id)); ?>" class="btn btn-success">
                                            <i class="material-icons">clear_all</i>
                                        </a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php else: ?>
                                <td>موردی یافت نشد</td>
                            <?php endif; ?>
                        </table>
                        <span dir="ltr"><a href="<?php echo e($items->previousPageUrl()); ?>" class="btn btn-light"><i
                                    class="material-icons text-dark">arrow_back</i>
                            </a>
                            <?php for($i=1;$i<=$items->lastPage();$i++): ?><a href="<?php echo e($items->url($i)); ?>" class="btn btn-light page-item"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                            <a href="<?php echo e($items->nextPageUrl()); ?>" class="btn btn-light">
                                <i class="material-icons text-dark">arrow_forward</i>
                            </a>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/Indicator.blade.php ENDPATH**/ ?>