<?php $__env->startSection($title, 'title'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <!-- Panel Content -->
        <div class="row no-gutters">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- Panel Body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12">
                        <!-- Print Button -->
                        <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2 mt-5"><i class="material-icons">print</i></button>
                        <!-- Content to be Printed -->
                        <span id="printdivcontent">
                            <table class="table text-center mt-5" dir="rtl">
                                <thead>
                                    <tr>
                                        <th colspan="2" class="bg-info"> لینک های محصول <?php echo e($item->PName); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Product Details -->
                                    <tr class="text-center">
                                        <th scope="col">تاریخ ثبت</th>
                                        <td><?php echo e($item->date); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="col">نام محصول</th>
                                        <td><?php echo e($item->PName); ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="col">زیر مجموعه اول</th>
                                        <td><?php echo e($item->ProName1); ?></td>
                                    </tr>
                                    <!-- Additional Sub Categories -->
                                    <?php for($i = 2; $i <= 20; $i++): ?>
                                        <?php if(!$item->{"ProName$i"} == ""): ?>
                                            <tr>
                                                <th scope="col">زیر مجموعه <?php echo e($i); ?></th>
                                                <td><?php echo e($item->{"ProName$i"}); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                    <!-- Back Button -->
                                    <tr>
                                        <td colspan="2"><a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger btn-block mb-2">بازگشت</a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/LinksShow.blade.php ENDPATH**/ ?>