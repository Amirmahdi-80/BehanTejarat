<?php $__env->startSection($title,'title'); ?>
<?php $__env->startSection('ZPanel'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading clearfix">
                    <div class="panel-title w-100 text-dark text-center"><?php echo e($title); ?></div>
                </div>
                <!-- panel body -->
                <div class="panel-body mt-5">
                    <?php echo csrf_field(); ?>
                    <?php echo e(html()->model($item)->form('PATCH', route('Admin.RegUp.update',$item->id))->attribute('enctype="multipart/form-data"')->open()); ?>

                    <table class="table text-right" dir="rtl">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <td scope="row"><?php echo e($item -> id); ?></td>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="col">نام</th>
                            <td><?php echo e(html()->text('Firstname')->class('form-control')->id('Firstname')->placeholder('نام')); ?>

                                <?php $__errorArgs = ['Firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                        </tr>
                        <tr>
                            <th scope="col">نام خانوادگی</th>
                            <td><?php echo e(html()->text('Lastname')->class('form-control')->id('Lastname')->placeholder('نام خانوادگی')); ?>

                                <?php $__errorArgs = ['Lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                        </tr>
                        <tr>
                            <th scope="col">ایمیل</th>
                            <td><?php echo e(html()->text('email')->class('form-control')->id('email')->placeholder('ایمیل')); ?>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                        </tr>
                        <tr>
                            <th scope="col">عکس پروفایل</th>
                            <td>
                                <input type="file" name="avatar" id="avatar" class="hidden">
                                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                        </tr>
                        <tr>
                            <td>
                                <button type="submit" class="btn btn-success">ویرایش</button>
                            </td>
                            <td>
                                <a href="<?php echo e(route('Admin.RegUp.index')); ?>" class="btn btn-danger">بازگشت</a>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <?php echo e(html()->form()->close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Auth/EditMe.blade.php ENDPATH**/ ?>