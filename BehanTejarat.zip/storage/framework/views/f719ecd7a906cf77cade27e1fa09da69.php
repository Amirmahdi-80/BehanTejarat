<?php $__env->startSection($title,'title'); ?>
<?php $__env->startSection('ZPanel'); ?>
    <div class="row no-gutters">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <!-- panel body -->
                <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12 mt-5">
                    <div class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                        <img src="<?php echo e(asset('assets/images/EditUser.png')); ?>" alt="ویرایش اطلاعات" class="img2">
                        <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                        <p>شما میتوانید اطلاعات حساب کاربری خود را از طریق جدول زیر ویرایش کنید</p>
                    </div>
                    <span></span>
                        <div class="d-flex flex-column justify-content-center align-items-center w-100">
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->Firstname == auth()->user()->Firstname ): ?>
                            <table class="table text-center w-100" dir="rtl">
                                <thead>
                                <tr>
                                    <th scope="col" colspan="2" class="bg-info text-light">در جدول زیر ما برخی اطلاعات از شما را نمایش میدهیم</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>
                                        عکس پروفایل:
                                    </td>
                                    <td>
                                        <?php if(auth()->user()->avatar  == ""): ?>
                                            <img src="<?php echo e(asset('assets/images/Sign-up.png')); ?>"
                                                 alt="<?php echo e($item->Firstname . ' ' . $item->Lastname); ?>"
                                                 title="<?php echo e($item->Firstname . ' ' . $item->Lastname); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e($item->avatar ? route('showAvatar', [$item->avatar]) : ''); ?>"
                                                 alt="<?php echo e($item->Firstname . ' ' . $item->Lastname); ?>"
                                                 style="width: 75px;height: 75px;border-radius: 50px"
                                                 title="<?php echo e($item->Firstname . ' ' . $item->Lastname); ?>">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>نام شما:</td>
                                    <td><?php echo e($item->Firstname); ?></td>
                                </tr>
                                <tr>
                                    <td>نام خانوادگی شما:</td>
                                    <td><?php echo e($item->Lastname); ?></td>
                                </tr>
                                <tr>
                                    <td>ایمیل شما:</td>
                                    <td><?php echo e($item->email); ?></td>
                                </tr>
                                <tr>
                                    <td>سِمَت شما:</td>
                                    <td><?php if($item->Role == ""): ?>
                                            سمت شما تعیین نشده
                                        <?php else: ?>
                                            <?php echo e($item->Role); ?>

                                        <?php endif; ?></td>
                                </tr>
                                <tr>
                                    <td>ویرایش اطلاعات:</td>
                                    <td><a href="<?php echo e(route('Admin.RegUp.edit',$item->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a></td>
                                </tr>
                                <tr>
                                    <td>حذف حساب کاربری:</td>
                                    <td><?php echo e(html()->form('DELETE', route('Admin.RegUp.destroy', $item->id))->open()); ?>

                                        <button class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                        <?php echo e(html()->form()->close()); ?></a></td>
                                </tr>
                                </tbody>
                            </table>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Auth/Me.blade.php ENDPATH**/ ?>