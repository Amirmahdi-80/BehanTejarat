<?php $__env->startSection($title,'title'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row overflow-auto mt-5">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- Panel body -->
                    <div class="panel-body">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($item)): ?>
                            
                            <?php echo e(html()->model($item)->form('PATCH', route('Admin.Out.update', $item->id))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php else: ?>
                            
                            <?php echo e(html()->form('POST', route('Admin.Out.store'))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php endif; ?>
                        <table class="table text-right table-borderless" dir="rtl">
                            <tbody>
                            <tr>
                                <?php if(isset($item)): ?>
                                    <th scope="col">نام محصول</th>
                                    <td><?php echo e(html()->text('PName')->class('form-control')->value($item->PName)->isReadonly()); ?></td>
                                <?php else: ?>
                                    <th scope="col">انتخاب محصول</th>
                                    <?php if($Products->isNotEmpty()): ?>
                                        <td>
                                            
                                            <?php echo e(html()->select('PName')->class('form-select')->open()); ?>

                                            <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e(html()->option($product->ProductComment)->value($product->ProductComment)); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(html()->select()->close()); ?>

                                        </td>
                                    <?php else: ?>
                                        
                                        <td>
                                            <?php echo e(html()->text()->class('form-control border-1 border-danger text-danger')->value('لطفا ابتدا محصول وارد کنید')->disabled()); ?>

                                        </td>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php $__errorArgs = ['PName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <tr>
                                <?php if(isset($item)): ?>
                                    <th scope="col">نام تامین کننده</th>
                                    <td><?php echo e(html()->text('TName')->class('form-control')->value($item->TName)->isReadonly()); ?></td>
                                <?php else: ?>
                                    <th scope="col">انتخاب تامین کننده</th>
                                    <?php if($Tamin->isNotEmpty()): ?>
                                        <td>
                                            
                                            <?php echo e(html()->select('TName')->class('form-select')->open()); ?>

                                            <?php $__currentLoopData = $Tamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tamin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e(html()->option($tamin->TaminName)->value($tamin->TaminName)); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(html()->select()->close()); ?>

                                        </td>
                                    <?php else: ?>
                                        
                                        <td class="">
                                            <?php echo e(html()->text()->class('form-control border-1 border-danger text-danger')->value('لطفا ابتدا تامین کننده وارد کنید')->disabled()); ?>

                                        </td>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php $__errorArgs = ['TName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <tr>
                                
                                <th scope="col">تاریخ خروج</th>
                                <td><?php echo e(html()->text('date')->class('form-control date1')->id('date')->placeholder('تاریخ خروج')->attribute('autocomplete','off')); ?></td>
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <?php if(isset($item)): ?>
                                <tr>
                                    
                                    <th scope="col">قیمت خروجی</th>
                                    <td><?php echo e(html()->text('exitPrice')->class('form-control')->id('exitPrice')->placeholder('قیمت خروج')->attribute("oninput=javascript:FormatNumber('exitPrice','exitPrice1');")); ?></td>
                                    <?php $__errorArgs = ['enterPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                <tr>
                                    
                                    <th scope="col">مرتب شده قیمت خروجی</th>
                                    <td><?php echo e(html()->text()->class('form-control')->id('exitPrice1')->placeholder('مرتب شده قیمت خروجی')->isReadonly()); ?></td>
                                </tr>
                                <tr>
                                    
                                    <th scope="col">مقدار خروجی</th>
                                    <td><?php echo e(html()->text('Count')->class('form-control')->id('Count')->placeholder('مقدار خروجی')->attribute('onkeyup="ca2()"')); ?></td>
                                    <?php $__errorArgs = ['Count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                <tr>
                                    
                                    <th scope="col">قیمت کل خروجی</th>
                                    <td><?php echo e(html()->text('TotalPrice')->class('form-control')->id('TotalPrice')->placeholder('قیمت کل خروجی')->isReadonly()); ?></td>
                                    <?php $__errorArgs = ['TotalPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($product->ProductComment == $item->PName): ?>
                                        <tr>
                                            <th scope="col">مقدار موجود در انبار</th>
                                            <td><?php echo e(html()->text()->class('form-control')->id('Count1')->placeholder('مقدار موجود در انبار')->value($product->Storage)->isReadonly()); ?></td>
                                        <tr>
                                            <th scope="col">قیمت موجود در انبار</th>
                                            <td><?php echo e(html()->text()->class('form-control')->id('Price1')->placeholder('قیمت موجود در انبار')->value($product->Price)->isReadonly()); ?></td>
                                        </tr>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <th scope="col">مقدار کل با احتساب انبار</th>
                                    <td><?php echo e(html()->text('Count2')->class('form-control')->id('Count2')->placeholder('مقدار کل با احتساب انبار')->isReadonly()); ?></td>
                                    <?php $__errorArgs = ['Count2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                <tr>
                                    
                                    <th scope="col">قیمت کل با احتساب انبار</th>
                                    <td><?php echo e(html()->text('TotalPrice2')->class('form-control')->id('TotalPrice2')->placeholder('قیمت کل با احتساب انبار')->isReadonly()); ?></td>
                                    <?php $__errorArgs = ['TotalPrice2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                
                                <?php if($Tamin->isNotEmpty() && $Products->isNotEmpty()): ?>
                                    <td><button type="submit" class="btn btn-success">ثبت محصول</button></td>
                                <?php else: ?>
                                    
                                    <td><button type="button" class="btn btn-sm btn-warning disabled" style="font-size: 12px">ابتدا مقادیر خواسته شده را تکمیل کنید</button></td>
                                <?php endif; ?>
                                <td>
                                    
                                    <a href="<?php echo e(route('Admin.Out.index')); ?>" class="btn btn-danger">بازگشت</a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <?php echo e(html()->form()->close()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/OutAdd.blade.php ENDPATH**/ ?>