<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="صفحه ثبت نام و ورود به پننل شرکت بهان تجارت به جهت کنترل انواع قسمت های آن">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/signup.css?v=version2')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css?v=version2')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon2.png')); ?>" type="image/x-icon">
    <script src="<?php echo e(asset('assets/js/app2.js?v=version2')); ?>"></script>
</head>
<body onload="load2()" id="body">
<?php echo $__env->yieldContent('content'); ?>

</body>
<?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Auth/LinkAuth.blade.php ENDPATH**/ ?>