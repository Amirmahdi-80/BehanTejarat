<?php $__env->startSection('title', $title); ?>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cars')): ?>
    
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row overflow-auto mt-5">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- panel body -->
                    <div class="panel-body">
                        
                        <?php echo csrf_field(); ?>
                        
                        <?php if(isset($item)): ?>
                            <?php echo e(html()->model($item)->form('PATCH', route('Admin.Cars.update', $item->id))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php else: ?>
                            <?php echo e(html()->form('POST', route('Admin.Cars.store'))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php endif; ?>
                        
                        <table class="table text-right table-borderless" dir="rtl">
                            <tbody>
                            
                            <tr>
                                <th scope="col">نام خودرو</th>
                                <td><?php echo e(html()->text('CarName')->class('form-control')->id('CarName')->placeholder('نام خودرو')); ?></td>
                                <?php $__errorArgs = ['CarName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td><span class="text-danger"><?php echo e($message); ?></span></td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            
                            <tr>
                                <th scope="col">شماره پلاک خودرو</th>
                                <td><?php echo e(html()->text('CarPlate')->class('form-control text-right')->id('CarPlate')->placeholder('شماره پلاک خودرو')); ?></td>
                                <?php $__errorArgs = ['CarPlate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td><span class="text-danger"><?php echo e($message); ?></span></td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            
                            <tr>
                                <th scope="col">رنگ خودرو</th>
                                <td><?php echo e(html()->text('CarColor')->class('form-control')->id('CarColor')->placeholder('رنگ خودرو')); ?></td>
                                <?php $__errorArgs = ['CarColor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td><span class="text-danger"><?php echo e($message); ?></span></td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            
                            <tr>
                                <th scope="col">کارکرد خودرو</th>
                                <td><?php echo e(html()->text('Kilometer')->class('form-control')->id('Kilometer')->placeholder('کارکرد خودرو')); ?></td>
                                <?php $__errorArgs = ['Kilometer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td><span class="text-danger"><?php echo e($message); ?></span></td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            
                            <tr>
                                <th scope="col">عکس</th>
                                <td><?php echo e(html()->file('image')->name('image')->id('image')->class('form-control-file')); ?></td>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td><span class="text-danger"><?php echo e($message); ?></span></td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            
                            <tr>
                                <th scope="col">بیمه شخص ثالث</th>
                                <td>
                                    <?php echo e(html()->file('BimeSales')->name('BimeSales')->id('BimeSales')->class('form-control-file')); ?></td>
                                <?php $__errorArgs = ['BimeSales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </tr>
                            
                            <tr>
                                <th scope="col">کارت خودرو</th>
                                <td>
                                    <?php echo e(html()->file('CarCard')->name('CarCard')->id('CarCard')->class('form-control-file')); ?>

                                    <?php $__errorArgs = ['CarCard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="col">برگه سبز</th>
                                <td>
                                    <?php echo e(html()->file('BargSabz')->name('BargSabz')->id('BargSabz')->class('form-control-file')); ?>

                                    <?php $__errorArgs = ['BargSabz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            
                            <tr>
                                <th scope="col">بیمه بدنه</th>
                                <td>
                                    <?php echo e(html()->file('Badane')->name('Badane')->id('Badane')->class('form-control-file')); ?>

                                    <?php $__errorArgs = ['Badane'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            
                            <tr>
                                <td><button type="submit" class="btn btn-success">ثبت</button></td>
                                <td>
                                    <a href="<?php echo e(route('Admin.Cars.index')); ?>">
                                        <button class="btn btn-danger" type="button">بازگشت</button>
                                    </a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        
                        <?php echo e(html()->form()->close()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Cars/CarsAdd.blade.php ENDPATH**/ ?>