<?php $__env->startSection($title, 'title'); ?>


<?php $__env->startSection($about, 'about'); ?>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    
    <?php $__env->startSection('ZPanel'); ?>
        <div class="container-fluid p-0">
            <div class="panel panel-primary">
                
                <div class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                    <img src="<?php echo e(asset('assets/images/Out.png')); ?>" alt="خروجی های محصول(حواله)" class="img2">
                    <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                    <p><?php echo e($about); ?></p>
                </div>
                
                <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12">
                    
                    <span class="d-flex row justify-content-center align-items-center">
                        <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2">
                            <i class="material-icons">print</i>
                        </button>
                        <a href="<?php echo e(route('Admin.searchOut')); ?>" class="btn btn-info">جست و جو</a>
                    </span>
                    
                    <a href="<?php echo e(route('Admin.Out.create')); ?>" class="btn btn-block btn-info">افزودن خروجی محصول(حواله)<i
                            class="material-icons">add_circle_outline</i></a>
                    
                    <div class="table-responsive" id="printdivcontent">
                        <table class="table text-center" dir="rtl">
                            <thead>
                            <tr>
                                <th scope="col">تاریخ ثبت</th>
                                <th scope="col">نام محصول</th>
                                <th scope="col">نام تامین کننده</th>
                                <th scope="col">تاریخ خروج</th>
                                <th scope="col">قیمت خروجی</th>
                                <th scope="col">مقدار خروجی</th>
                                <th scope="col">قیمت کل خروجی</th>
                                <th scope="col">جزئیات</th>
                                <th scope="col">ویرایش</th>
                                <th scope="col">حذف</th>
                            </tr>
                            </thead>
                            <tbody>
                            
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item->TS); ?></td>
                                    <td><?php echo e($item->PName); ?></td>
                                    <td><?php echo e($item->TName); ?></td>
                                    <td><?php echo e($item->date); ?></td>
                                    
                                    <td dir="rtl">
                                        <?php if($item->exitPrice == ""): ?>
                                            <span class="text-danger">نیازمند ویرایش</span>
                                        <?php else: ?>
                                            <?php echo e(number_format($item->exitPrice, 0, ".", ",")); ?> ريال
                                        <?php endif; ?>
                                    </td>
                                    <td dir="rtl">
                                        <?php if($item->Count == ""): ?>
                                            <span class="text-danger">نیازمند ویرایش</span>
                                        <?php else: ?>
                                            <?php echo e(number_format($item->Count, 0, ".", ",")); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td dir="rtl">
                                        <?php if($item->TotalPrice == ""): ?>
                                            <span class="text-danger">نیازمند ویرایش</span>
                                        <?php else: ?>
                                            <?php echo e(number_format($item->TotalPrice, 0, ".", ",")); ?> ريال
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <a href="<?php echo e(route('Admin.Out.show', $item->id)); ?>" class="btn btn-info">
                                            <i class="material-icons">remove_red_eye</i>
                                        </a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('Admin.Out.edit', $item->id)); ?>" class="btn btn-warning">
                                            <i class="material-icons">edit</i>
                                        </a>
                                    </td>
                                    <td>
                                        
                                        <?php echo e(html()->form('DELETE', route('Admin.Out.destroy', $item->id))->open()); ?>

                                        <button class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                        <?php echo e(html()->form()->close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <span dir="ltr">
                        <a href="<?php echo e($items->previousPageUrl()); ?>" class="btn btn-light">
                            <i class="material-icons text-dark">arrow_back</i>
                        </a>
                        <?php for($i=1; $i<=$items->lastPage(); $i++): ?>
                            <a href="<?php echo e($items->url($i)); ?>" class="btn btn-light page-item"><?php echo e($i); ?></a>
                        <?php endfor; ?>
                        <a href="<?php echo e($items->nextPageUrl()); ?>" class="btn btn-light">
                            <i class="material-icons text-dark">arrow_forward</i>
                        </a>
                    </span>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/Out.blade.php ENDPATH**/ ?>