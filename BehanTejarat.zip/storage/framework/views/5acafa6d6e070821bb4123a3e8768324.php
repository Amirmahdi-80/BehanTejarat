<?php $__env->startSection('content'); ?>
    <body>
    <img src="<?php echo e(asset('assets/images/Logo.png')); ?>" alt="Logo" style="position: fixed;top: 0px;right: 10px">
    <div class="context">
        <div class="session">
            <img class="left" src="<?php echo e(asset('assets/images/Register.jpg')); ?>" alt="Register">
            <div class="No1" dir="ltr">
                <form action="<?php echo e(route('signup.register')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <h4 class="text-right w-100">فرم ثبت نام</h4>
                    <p class="w-100 text-right p-0">جهت ثبت نام در سایت فرم زیر را تکمیل کنید</p>
                    <div class="floating-label">
                        <input placeholder="نام" type="text" name="Firstname" id="Firstname" class="pr-2"
                               value="<?php echo e(old('Firstname')); ?>">
                        <label for="Firstname" class="pr-2">نام:</label>
                        <?php $__errorArgs = ['Firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 12px"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="floating-label">
                        <input placeholder="نام خانوادگی" type="text" name="Lastname" id="Lastname" class="pr-2"
                               value="<?php echo e(old('Lastname')); ?>">
                        <label for="Lastname" class="pr-2">نام خانوادگی:</label>
                        <?php $__errorArgs = ['Lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 12px"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="floating-label">
                        <input placeholder="ایمیل" type="text" name="email" id="email" class="pr-2"
                               value="<?php echo e(old('email')); ?>">
                        <label for="email" class="pr-2">ایمیل:</label>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 12px"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="floating-label">
                        <input placeholder="رمز عبور" type="password" name="password" id="password" class="pr-2"
                               value="">
                        <label for="password" class="pr-2">رمز عبور:</label>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 12px"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="floating-label">
                        <input placeholder="تکرار رمز عبور" type="password" name="password_confirmation"
                               id="password_confirmation" class="pr-2">
                        <label for="password" class="pr-2">تکرار رمز عبور:</label>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 12px"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="floating-label">
                        <input type="file" name="avatar" id="avatar" class="hidden" style="visibility: hidden">
                        <label for="avatar" class="form-control"
                               style="border: 1px solid gainsboro;background-color: #fff">عکس پروفایل</label>
                        <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="font-size: 12px"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <span class="d-flex row justify-content-between align-items-center w-100 mr-0">
                <button type="submit" class="btn btn-success">ثبت نام</button>
                <a href="<?php echo e(route('Home.index')); ?>" class="btn btn-danger">بازگشت</a>
            </span>
                    <span class="No2"><a href="<?php echo e(route('login')); ?>" class="text-decoration-none discrete text-right m-2"
                                         target="_blank">اکانت دارید؟ ورود کنید</a></span>
                </form>
            </div>
        </div>
    </div>
    <div class="area">
        <ul class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Auth.LinkAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Auth/Register.blade.php ENDPATH**/ ?>