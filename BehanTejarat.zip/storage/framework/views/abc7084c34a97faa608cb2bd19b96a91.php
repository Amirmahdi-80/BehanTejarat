<?php $__env->startSection($title, 'title'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cars')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="container-fluid p-0">
            <div class="panel panel-primary">
                <div class="panel-heading clearfix d-flex flex-column justify-content-center align-items-center">
                    <img src="<?php echo e(asset('assets/images/Search.png')); ?>" alt="جست و جو در خودرو ها" class="img2">
                    <h1 class="panel-title text-dark text-center mb-3 mt-2"><?php echo e($title); ?></h1>
                </div>

                <span class="d-flex flex-column justify-content-center align-items-center">
                    <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2"><i
                            class="material-icons">print</i></button>
                    <label style="border-bottom: 2px dashed gray;width: 30%;color: #333" class="text-center pb-2">فیلتر بر اساس جست و جو</label>

                    <form action="<?php echo e(route('Admin.search')); ?>" method="GET"
                          class="text-dark d-flex row justify-content-center align-items-center mb-4 search no-gutters">
                        <input type="text" name="search" class="text-dark" placeholder="جست و جو کنید">
                        <button type="submit"><i class="material-icons">search</i></button>
                    </form>

                    <label style="border-bottom: 2px dashed gray;width: 30%;color: #333" class="text-center pb-2">فیلتر بر اساس تاریخ</label>

                    <form action="<?php echo e(route('Admin.filter')); ?>" method="GET"
                          class="text-dark d-flex row justify-content-center align-items-center mb-4 search no-gutters No4">
                        <label>از تاریخ:</label>
                        <input type="text" name="date" class="text-dark date1">
                        <label>تا تاریخ:</label>
                        <input type="text" name="date2" class="text-dark date1">
                        <button type="submit"><i class="material-icons">filter_list</i></button>
                    </form>

                    <a href="<?php echo e(route('Admin.CarsTransfer.index')); ?>" class="btn btn-outline-danger mb-3">بازگشت</a>
                </span>

                <!-- panel body -->
                <div
                    class="panel-body d-flex flex-column justify-content-center align-items-center w-100 overflow-auto">
                    <div class="table-responsive" id="printdivcontent">
                        <?php if($items->isNotEmpty()): ?>
                            <table class="table mb-2">
                                <tr class="text-center">
                                    <th>
                                        کل مسافت طی شده گزارش
                                    </th>
                                    <th>
                                        تاریخ گزارش گیری
                                    </th>
                                    <th>
                                        خودرو های گزارش:
                                    </th>
                                </tr>
                                <tr class="text-center" dir="ltr">
                                    <td>
                                        <?php echo e(number_format($Kil, 0, ".", ",")); ?> Km
                                    </td>
                                    <td>
                                        <?php echo e(jdate()); ?>

                                    </td>
                                    <td>
                                        <?php if($search === null): ?>
                                            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($car->CarName); ?>

                                                <?php if(!$loop->last): ?>
                                                    
                                                    ,
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php echo e($search); ?>

                                        <?php endif; ?>
                                    </td>

                                </tr>
                            </table>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <table class="table text-center table-responsive mb-2" dir="rtl"
                                       style="border-bottom: 3px solid #333">
                                    <thead class="bg-info">
                                    <tr>
                                        <th scope="col">تاریخ</th>
                                        <th scope="col">نام خودرو</th>
                                        <th scope="col">نام راننده</th>
                                        <th scope="col">توضیحات</th>
                                        <th scope="col">عکس راننده</th>
                                        <th scope="col">عکس خودرو</th>
                                        <th scope="col">شماره پلاک خودرو</th>
                                        <th scope="col">کیلومتر خروج</th>
                                        <th scope="col">کیلومتر ورود</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr class="text-center">
                                        <td><?php echo e($item->date); ?></td>
                                        <td><?php echo e($item->car_id); ?></td>
                                        <td><?php echo e($item->driver_id); ?></td>
                                        <td><?php echo e($item->Tozih); ?></td>
                                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($driver->DriverName == $item->driver_id): ?>
                                                <td data-toggle="tooltip" data-placement="bottom"
                                                    title="برای دانلود عکس کلیک کنید">
                                                    <?php if(!$driver->image == ""): ?>
                                                        <a href="<?php echo e(route('files.show', $driver->image)); ?>"><img
                                                                class="avatar img-circle"
                                                                src="<?php echo e(route('files.show', $driver->image)); ?>"
                                                                alt="عکس راننده خودرو" title="عکس راننده خودرو"
                                                                style="border-radius: 5px;width: 50px; height: 50px;"></a>
                                                    <?php else: ?>
                                                        <span>خالی</span>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($car->CarName == $item->car_id): ?>
                                                <td data-toggle="tooltip" data-placement="bottom"
                                                    title="برای دانلود عکس کلیک کنید">
                                                    <?php if(!$car->image == ""): ?>
                                                        <a href="<?php echo e(route('files.show', $car->image)); ?>"><img
                                                                class="avatar img-circle"
                                                                src="<?php echo e(route('files.show', $car->image)); ?>"
                                                                alt="عکس خودرو" title="عکس خودرو"
                                                                style="border-radius: 5px;width: 50px; height: 50px;"></a>
                                                    <?php else: ?>
                                                        <span>خالی</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($car->CarPlate); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e(number_format($item->ExitDistance, 0, ".", ",") . 'Km'); ?></td>
                                        <td><?php echo e(number_format($item->EnterDistance, 0, ".", ",") . 'Km'); ?></td>
                                    </tr>
                                    </tbody>
                                    <thead>
                                    <tr>
                                        <th scope="col">ساعت خروج اول</th>
                                        <th scope="col">ساعت ورود اول</th>
                                        <th scope="col">ساعت خروج دوم</th>
                                        <th scope="col">ساعت ورود دوم</th>
                                        <th scope="col">ساعت خروج سوم</th>
                                        <th scope="col">ساعت ورود سوم</th>
                                        <th scope="col">ساعت خروج چهارم</th>
                                        <th scope="col">ساعت ورود چهارم</th>
                                        <th scope="col">کیلومتر پیموده</th>
                                    </tr>
                                    </thead>
                                    <tbody class="mb-3">
                                    <tr>
                                        <td><?php echo e($item->exit1); ?></td>
                                        <td><?php echo e($item->enter1); ?></td>
                                        <td><?php echo e($item->exit2); ?></td>
                                        <td><?php echo e($item->enter2); ?></td>
                                        <td><?php echo e($item->exit3); ?></td>
                                        <td><?php echo e($item->enter3); ?></td>
                                        <td><?php echo e($item->exit4); ?></td>
                                        <td><?php echo e($item->enter4); ?></td>
                                        <td><?php echo e(number_format($item->kilometer, 0, ".", ",") . 'Km'); ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div>
                                <h2 class="text-dark mt-5 d-flex row justify-content-center align-items-center"
                                    style="gap: 10px">نتیجه ای یافت نشد<i class="material-icons text-dark">mood_bad</i>
                                </h2>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Cars/search.blade.php ENDPATH**/ ?>