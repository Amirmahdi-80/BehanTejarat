<?php $__env->startSection($title, 'title'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <!-- Form Section -->
        <div class="d-flex justify-content-center align-items-center no-gutters w-100">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- Panel Body -->
                    <div class="panel-body">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($item)): ?>
                            <!-- Update Form -->
                            <?php echo e(html()->model($item)->form('PATCH', route('Admin.Links.update', $item->id))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php else: ?>
                            <!-- Create Form -->
                            <?php echo e(html()->form('POST', route('Admin.Links.store'))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php endif; ?>
                        <table class="table text-right mt-5 w-100" dir="rtl">
                            <tbody>
                            <!-- Product Name -->
                            <tr>
                                <th scope="col">نام محصول</th>
                                <td>
                                    <?php echo e(html()->select('PName')->open()); ?>

                                    <?php if(isset($item)): ?>
                                        <?php echo e(html()->option($item->PName)->value($item->PName)); ?>

                                    <?php endif; ?>
                                    <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(html()->option($Product->ProductComment)->value($Product->ProductComment)); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e(html()->select()->close()); ?>

                                    <?php $__errorArgs = ['PName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <!-- Registration Date -->
                            <tr style="border-bottom: 3px dashed #333 !important;">
                                <th scope="col">تاریخ ثبت محصول</th>
                                <td>
                                    <?php echo e(html()->text('date')->class('form-control date1')->attribute('autocomplete="off"')); ?>

                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <!-- Sub Categories -->
                            <tr>
                                <th scope="col">زیر مجموعه اول</th>
                                <td>
                                    <?php echo e(html()->select('ProName1')->open()); ?>

                                    <?php if(isset($item)): ?>
                                        <?php echo e(html()->option($item->ProName1)->value($item->ProName1)->selected()); ?>

                                    <?php else: ?>
                                        <?php echo e(html()->option("انتخاب کنید")->value(null)->selected()->disabled()); ?>

                                    <?php endif; ?>
                                    <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(html()->option($Product->ProductComment)->value($Product->ProductComment)); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e(html()->select()->close()); ?>

                                    <?php $__errorArgs = ['ProName1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <!-- Additional Sub Categories -->
                            <?php for($i = 2; $i <= 20; $i++): ?>
                                <tr>
                                    <th scope="col">زیر مجموعه <?php echo e($i); ?></th>
                                    <td>
                                        <?php echo e(html()->select("ProName$i")->open()); ?>

                                        <?php if(isset($item)): ?>
                                            <?php echo e(html()->option($item->{"ProName$i"})->value($item->{"ProName$i"})->selected()); ?>

                                        <?php else: ?>
                                            <?php echo e(html()->option("انتخاب کنید")->value(null)->selected()->disabled()); ?>

                                        <?php endif; ?>
                                        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(html()->option($Product->ProductComment)->value($Product->ProductComment)); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(html()->select()->close()); ?>

                                        <?php $__errorArgs = ["ProName$i"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>
                            <?php endfor; ?>
                            <!-- Form Submission Buttons -->
                            <tr>
                                <td>
                                    <button type="submit" class="btn btn-success">اعمال</button>
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger">بازگشت</a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <?php echo e(html()->form()->close()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/LinksAdd.blade.php ENDPATH**/ ?>