<?php $__env->startSection($title,'title'); ?>
<?php $__env->startSection($about,'about'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cars')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row overflow-auto w-100">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div
                        class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                        <img src="<?php echo e(asset('assets/images/Driver.png')); ?>" alt="خودروها" class="img2">
                        <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                        <p><?php echo e($about); ?></p>
                        <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2"><i
                                class="material-icons">print</i></button>
                    </div>
                    <!-- panel body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12" id="printdivcontent">
                        <table class="table text-right" dir="rtl">
                            <thead>
                            <a href="<?php echo e(route('Admin.Driver.create')); ?>" class="btn btn-block btn-info">افزودن راننده<i
                                    class="material-icons">add_circle_outline</i></a>
                            <tr>
                                <th scope="col" class="text-center">نام راننده</th>
                                <th scope="col" class="text-center">شماره ملی راننده</th>
                                <th scope="col" class="text-center">شماره تماس راننده</th>
                                <th scope="col" class="text-center">عکس گواهینامه راننده</th>
                                <th scope="col" class="text-center">مشاهده عکس پروفایل</th>
                                <th scope="col" class="text-center">ویرایش</th>
                                <th scope="col" class="text-center">حذف</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item -> DriverName); ?></td>
                                    <td><?php echo e($item -> MeliCode); ?></td>
                                    <td><?php echo e($item -> DriverNumber); ?></td>
                                    <td>
                                        <?php if(!$item->DriverLicence==""): ?>
                                        <a href="<?php echo e(route("files.show", $item->DriverLicence)); ?>"><img
                                                class="avatar img-circle"
                                                src="<?php echo e(route("files.show", $item->DriverLicence)); ?>"
                                                alt="عکس گواهینامه" title="عکس گواهینامه"
                                                style="border-radius: 5px"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(!$item->image==""): ?>
                                            <a href="<?php echo e(route("files.show", $item->image)); ?>"><img class="avatar img-circle"
                                                                                                   src="<?php echo e(route("files.show", $item->image)); ?>"
                                                                                                   alt="<?php echo e($item -> DriverName); ?>" title="<?php echo e($item -> DriverName); ?>"
                                                                                                   style="border-radius: 50%"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('Admin.Driver.edit', $item->id)); ?>" class="btn btn-warning">
                                            <i class="material-icons">edit</i>
                                        </a></td>
                                    <td>
                                        <?php echo e(html()->form('DELETE', route('Admin.Driver.destroy', $item->id))->open()); ?>

                                        <button class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                        <?php echo e(html()->form()->close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <span dir="ltr" class="w-100 d-flex row justify-content-center align-items-center" style="gap: 10px"><a href="<?php echo e($items->previousPageUrl()); ?>" class="btn btn-light"><i class="material-icons text-dark">arrow_back</i>
                                </a>
                                <?php for($i=1;$i<=$items->lastPage();$i++): ?>
                            <a href="<?php echo e($items->url($i)); ?>" class="btn btn-light page-item"><?php echo e($i); ?></a>
                        <?php endfor; ?>
                                <a href="<?php echo e($items->nextPageUrl()); ?>" class="btn btn-light">
                                    <i class="material-icons text-dark">arrow_forward</i>
                                </a>
                            </span>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Admin/Driver/Driver.blade.php ENDPATH**/ ?>