<?php $__env->startSection('title', 'title'); ?> <!-- Assuming you want 'title' string as the title -->

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cars')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <!-- Car Entry Form -->
        <div class="mt-5">
                <div class="panel panel-primary">
                    <!-- Panel Body -->
                    <div class="panel-body">
                        <?php echo csrf_field(); ?> <!-- CSRF Protection -->
                        <!-- Form Open -->
                        <?php if(isset($item)): ?>
                            <?php echo e(html()->model($item)->form('PATCH', route('Admin.CarsTransfer.update', $item->id))->open()); ?>

                        <?php else: ?>
                            <?php echo e(html()->form('POST', route('Admin.CarsTransfer.store'))->open()); ?>

                        <?php endif; ?>
                        <table class="table text-right table-borderless" dir="rtl">
                            <tbody>
                            <!-- Date Field -->
                            <tr>
                                <th scope="col">تاریخ ثبت</th>
                                <td><?php echo e(html()->text('date')->class('form-control date1')->id('date1')->placeholder('تاریخ ثبت')); ?></td>
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Car Name Selection -->
                            <tr>
                                <th><label for="نام خودرو">نام خودرو</label></th>
                                <td class="d-flex flex-column justify-content-center align-items-center">
                                    <?php if($cars->isNotEmpty()): ?>
                                        <?php echo e(html()->select('car_id')->class('w-100')->open()); ?>

                                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(html()->option($car->CarName)->value($car->CarName)); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(html()->select()->close()); ?>

                                    <?php else: ?>
                                        <?php echo e(html()->text()->value('لطفا ابتدا خودرو را اضافه کنید')->class('form-control text-danger border-danger')->disabled()); ?>

                                    <?php endif; ?>
                                    <?php $__errorArgs = ['car_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <!-- Driver Name Selection -->
                            <tr>
                                <th><label for="نام راننده">نام راننده</label></th>
                                <td class="d-flex flex-column justify-content-center align-items-center">
                                    <?php if($drivers->isNotEmpty()): ?>
                                        <?php echo e(html()->select('driver_id')->class('w-100')->open()); ?>

                                        <?php if(isset($item)): ?>
                                            <?php echo e(html()->option($item->driver_id)->value($item->driver_id)->selected()); ?>

                                        <?php endif; ?>
                                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(html()->option($driver->DriverName)->value($driver->DriverName)); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(html()->select()->close()); ?>

                                    <?php else: ?>
                                        <?php echo e(html()->text()->value('لطفا ابتدا راننده را اضافه کنید')->class('form-control text-danger border-danger')->disabled()); ?>

                                    <?php endif; ?>
                                    <?php $__errorArgs = ['driver_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                            </tr>
                            <!-- Exit Kilometer -->
                            <tr>
                                <th scope="col">کیلومتر خروج</th>
                                <td><?php echo e(html()->text('ExitDistance')->class('form-control')->id('ExitDistance')->placeholder('کیلومتر خروج')); ?></td>
                                <?php $__errorArgs = ['ExitDistance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Exit time 1 -->
                            <tr>
                                <th scope="col">ساعت خروج اول</th>
                                <td><?php echo e(html()->text('exit1')->class('form-control')->id('exit1')->placeholder('ساعت خروج')); ?></td>
                                <?php $__errorArgs = ['exit1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Enter time 1 -->
                            <tr>
                                <th scope="col">ساعت ورود اول</th>
                                <td><?php echo e(html()->text('enter1')->class('form-control')->id('enter1')->placeholder('ساعت ورود')); ?></td>
                                <?php $__errorArgs = ['enter1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Exit time 2 -->
                            <tr>
                                <th scope="col">ساعت خروج دوم</th>
                                <td><?php echo e(html()->text('exit2')->class('form-control')->id('exit2')->placeholder('ساعت خروج')); ?></td>
                                <?php $__errorArgs = ['exit2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Enter time 2 -->
                            <tr>
                                <th scope="col">ساعت ورود دوم</th>
                                <td><?php echo e(html()->text('enter2')->class('form-control')->id('enter2')->placeholder('ساعت ورود')); ?></td>
                                <?php $__errorArgs = ['enter2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Exit time 3 -->
                            <tr>
                                <th scope="col">ساعت خروج سوم</th>
                                <td><?php echo e(html()->text('exit3')->class('form-control')->id('exit3')->placeholder('ساعت خروج')); ?></td>
                                <?php $__errorArgs = ['exit3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Enter time 3 -->
                            <tr>
                                <th scope="col">ساعت ورود سوم</th>
                                <td><?php echo e(html()->text('enter3')->class('form-control')->id('enter3')->placeholder('ساعت ورود')); ?></td>
                                <?php $__errorArgs = ['enter3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Exit time 4 -->
                            <tr>
                                <th scope="col">ساعت خروج چهارم</th>
                                <td><?php echo e(html()->text('exit4')->class('form-control')->id('exit4')->placeholder('ساعت خروج')); ?></td>
                                <?php $__errorArgs = ['exit4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Enter time 4 -->
                            <tr>
                                <th scope="col">ساعت ورود چهارم</th>
                                <td><?php echo e(html()->text('enter4')->class('form-control')->id('enter4')->placeholder('ساعت ورود')); ?></td>
                                <?php $__errorArgs = ['enter4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Enter kilometer -->
                            <tr>
                                <th scope="col">کیلومتر ورود</th>
                                <td><?php echo e(html()->text('EnterDistance')->class('form-control')->id('EnterDistance')->placeholder('کیلومتر ورود')->attribute('onchange=cal2()')); ?></td>
                                <?php $__errorArgs = ['EnterDistance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Distance traveled -->
                            <tr>
                                <th scope="col">کیلومتر پیموده</th>
                                <td><?php echo e(html()->text('Kilometer')->class('form-control')->id('Kilometer')->placeholder('کیلومتر پیموده')->isReadonly()); ?></td>
                                <?php $__errorArgs = ['Kilometer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>
                            <!-- Comments -->
                            <tr>
                                <th scope="col">توضیحات</th>
                                <td><?php echo e(html()->textarea('Tozih')->class('form-control')->id('Tozih')->placeholder('توضیحات')->style('resize:none;height:100px;font-size:10px')); ?></td>
                                <?php $__errorArgs = ['Tozih'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <td>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </td>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </tr>

                            <!-- Form Submission Buttons -->
                            <tr>
                                <td>
                                    <?php if($cars->isNotEmpty() && $drivers->isNotEmpty()): ?>
                                        <button type="submit" class="btn btn-success">ثبت</button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-success disabled" style="font-size: 10px">لطفا ابتدا مقادیر خواسته شده را تکمیل کنید</button>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('Admin.CarsTransfer.index')); ?>">
                                        <button class="btn btn-danger" type="button">بازگشت</button>
                                    </a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <!-- Form Close -->
                        </form><?php echo e(html()->form()->close()); ?>

                    </div>
                </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Cars/CarsAdd2.blade.php ENDPATH**/ ?>