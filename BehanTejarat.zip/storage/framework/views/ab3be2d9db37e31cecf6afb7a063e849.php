<?php $__env->startSection($title, 'title'); ?> <!-- Title section -->
<?php $__env->startSection($about, 'about'); ?> <!-- About section -->

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cars')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <!-- Print Button -->
        <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2 mt-5"><i class="material-icons">print</i></button>

        <!-- Print Content -->
        <div class="row" id="printdivcontent">
            <div>
                <div class="panel panel-primary">
                    <!-- Panel Body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center">
                        <!-- Form Open -->
                        <?php echo e(html()->model($item)->form('PATCH', route('Admin.CarsTransfer.update', $item->id))->open()); ?>

                        <table class="table text-right table-borderless mt-5" dir="rtl">
                            <tbody>
                            <!-- Data Rows -->
                            <tr>
                                <th>تاریخ</th>
                                <td><?php echo e($item->date); ?></td>
                            </tr>
                            <!-- Car Name -->
                            <tr>
                                <th>نام خودرو</th>
                                <td><?php echo e($item->car_id); ?></td>
                            </tr>
                            <!-- Driver Name -->
                            <tr>
                                <th>نام راننده</th>
                                <td>
                                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->driver_id == $driver->DriverName): ?>
                                            <?php echo e($driver->DriverName); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <!-- Exit kilometer -->
                            <tr>
                                <th scope="col">کیلومتر خروج:</th>
                                <td><?php echo e($item->ExitDistance); ?></td>
                            </tr>
                            <!-- Time -->
                            <tr>
                                <th scope="col">ساعت خروج اول:</th>
                                <td><?php echo e($item->exit1); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">ساعت ورود اول:</th>
                                <td><?php echo e($item->enter1); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">ساعت خروج دوم:</th>
                                <td><?php echo e($item->exit2); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">ساعت ورود دوم:</th>
                                <td><?php echo e($item->enter2); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">ساعت خروج سوم:</th>
                                <td><?php echo e($item->exit3); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">ساعت ورود سوم:</th>
                                <td><?php echo e($item->enter3); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">ساعت خروج چهارم:</th>
                                <td><?php echo e($item->exit4); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">ساعت ورود چهارم:</th>
                                <td><?php echo e($item->enter4); ?></td>
                            </tr>
                            <!-- Enter kilometer -->
                            <tr>
                                <th scope="col">کیلومتر ورود:</th>
                                <td dir="ltr"><?php echo e($item->EnterDistance); ?> Km</td>
                            </tr>
                            <!-- Distance traveled -->
                            <tr>
                                <th scope="col">کیلومتر پیموده:</th>
                                <td dir="ltr"><?php echo e($item->Kilometer); ?> Km</td>
                            </tr>
                            <!-- Driver Picture -->
                            <tr>
                                <th scope="col">عکس راننده:</th>
                                <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($driver->DriverName == $item->driver_id): ?>
                                        <td data-toggle="tooltip" data-placement="bottom"
                                            title="برای دانلود عکس کلیک کنید"><?php if(!$driver->image==""): ?>
                                                <a
                                                    href="<?php echo e(route("files.show", $driver->image)); ?>"><img
                                                        class="avatar img-circle"
                                                        src="<?php echo e(route("files.show", $driver->image)); ?>" alt="عکس راننده"
                                                        title="عکس راننده"
                                                        style="border-radius: 5px"></a>
                                            <?php else: ?>
                                                <span>خالی</span>
                                            <?php endif; ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <!-- CarPicture -->
                            <tr>
                                <th scope="col">عکس خودرو:</th>
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($car->CarName == $item->car_id): ?>
                                        <td data-toggle="tooltip" data-placement="bottom"
                                            title="برای دانلود عکس کلیک کنید">
                                            <?php if(!$car->image==""): ?>
                                                <a
                                                    href="<?php echo e(route("files.show", $car->image)); ?>"><img
                                                        class="avatar img-circle"
                                                        src="<?php echo e(route("files.show", $car->image)); ?>" alt="عکس خودرو"
                                                        title="عکس خودرو"
                                                        style="border-radius: 5px"></a>
                                            <?php else: ?>
                                                <span>خالی</span>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <!-- Plate -->
                            <tr>
                                <th scope="col">پلاک خودرو:</th>
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($car->CarName == $item->car_id): ?>
                                        <td><?php echo e($car->CarPlate); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <!-- Comments -->
                            <tr>
                                <th scope="col">توضیحات:</th>
                                <td><?php echo e($item->Tozih); ?></td>
                            </tr>
                            <!-- Buttons -->
                            <tr>
                                <td>
                                    <a href="<?php echo e(url()->previous()); ?>">
                                        <button class="btn btn-danger" type="button">بازگشت</button>
                                    </a>
                                </td>
                                <td>
                                    <a href="http://www.zg666gps.com/" class="btn btn-success">ردیابی</a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <!-- Form Close -->
                        <?php echo e(html()->form()->close()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Cars/CarTransferShow.blade.php ENDPATH**/ ?>