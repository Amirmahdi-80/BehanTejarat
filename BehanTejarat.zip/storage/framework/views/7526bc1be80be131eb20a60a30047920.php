<?php $__env->startSection($title,'title'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-slides')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row no-gutters">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                        <img src="<?php echo e(asset('assets/images/Slider.png')); ?>" alt="کنترل اسلایدر ها" class="img2" style="border-radius: 50%">
                        <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                        <p>شما در این صفحه میتوانید اسبلایدر را حذف و اضافه کنید. بدین منظور از دکمه های درون جدول استفاده کنید.</p>
                    </div>
                    <!-- panel body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12">
                        <table class="table text-center" dir="rtl">
                            <thead>
                            <a href="<?php echo e(route('Admin.Slider.create')); ?>" class="btn btn-block btn-info">افزودن اسلاید<i class="material-icons">add_circle_outline</i></a>
                            <tr>
                                <th scope="col">نام اسلایدر</th>
                                <th scope="col">توضیحات</th>
                                <th scope="col">عکس اسلایدر</th>
                                <th scope="col">حذف</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item -> SlideName); ?></td>
                                    <td><?php echo e($item -> SlideTozih); ?></td>
                                    <td data-toggle="tooltip" data-placement="bottom"
                                        title="برای دانلود عکس کلیک کنید"><?php if(!$item->image==""): ?>
                                            <a href="<?php echo e(route("files.show", $item->image)); ?>"><img
                                                    class="avatar2 img-circle"
                                                    src="<?php echo e(route("files.show", $item->image)); ?>"
                                                    alt="<?php echo e($item -> SlideTozih); ?>" title="<?php echo e($item -> SlideTozih); ?>"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?></td>
                                    <td>
                                        <?php echo e(html()->form('DELETE', route('Admin.Slider.destroy', $item->id))->open()); ?>

                                        <button class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                        <?php echo e(html()->form()->close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <span dir="ltr"><a href="<?php echo e($items->previousPageUrl()); ?>" class="btn btn-light"><i class="material-icons text-dark">arrow_back</i>
                                </a>
                                <?php for($i=1;$i<=$items->lastPage();$i++): ?>
                                <a href="<?php echo e($items->url($i)); ?>" class="btn btn-light page-item"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                                <a href="<?php echo e($items->nextPageUrl()); ?>" class="btn btn-light">
                                    <i class="material-icons text-dark">arrow_forward</i>
                                </a>
                            </span>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Slider/Slideshow.blade.php ENDPATH**/ ?>