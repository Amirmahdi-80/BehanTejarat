<?php $__env->startSection($title,'title'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="d-flex row justify-content-center align-items-center no-gutters w-100">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- panel body -->
                    <div class="panel-body">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($item)): ?>
                            <?php echo e(html()->model($item)->form('PATCH', route('Admin.Products.update', $item->id))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php else: ?>
                            <?php echo e(html()->form('POST', route('Admin.Products.store'))->attribute('enctype="multipart/form-data"')->open()); ?>

                        <?php endif; ?>
                        <table class="table text-right mt-5" dir="rtl">
                            <thead>
                            <tr>
                                <th scope="col">دسته بندی</th>

                                <td>
                                    <?php if($Sorts->isnotempty()): ?>
                                    <?php echo e(html()->select('Sort')->class('form-select')->open()); ?>

                                    <?php if(isset($item)): ?>
                                            <?php echo e(html()->option($item->Sort)->value($item->Sort)->selected()); ?>

                                        <?php else: ?>
                                        <?php echo e(html()->option()->value('انتخاب کنید')); ?>

                                        <?php endif; ?>
                                    <?php $__currentLoopData = $Sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sort): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(html()->option($Sort->SortName)->value($Sort->SortName)); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e(html()->select()->close()); ?>

                                    <?php else: ?>
                                        <?php echo e(html()->text()->disabled()->class('form-control border-danger text-danger')->value('لطفا ابتدا دسته بندی اضافه کنید')); ?>

                                    <?php endif; ?>
                                    <?php $__errorArgs = ['Sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">نام محصول</th>
                                <td><?php echo e(html()->text('ProductComment')->class('form-control')->id('ProductComment')->placeholder('نام محصول')); ?>

                                    <?php $__errorArgs = ['ProductComment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">شناسه محصول</th>
                                <td><?php echo e(html()->text('ProductId')->class('form-control')->id('ProductId')->placeholder('شناسه محصول')); ?>

                                    <?php $__errorArgs = ['ProductId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">قیمت محصول</th>
                                <td><?php echo e(html()->text('Price')->class('form-control')->id('Price')->placeholder('قیمت محصول')); ?>

                                    <?php $__errorArgs = ['Price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">واحد</th>
                                <td>
                                    <?php if($Vaheds->isnotempty()): ?>
                                    <?php echo e(html()->select('Vahed')->class('form-select')->open()); ?>

                                        <?php $__currentLoopData = $Vaheds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Vah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(html()->option($Vah->VahedName2)->value($Vah->VahedName2)); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e(html()->select()->close()); ?>

                                    <?php else: ?>
                                        <?php echo e(html()->text()->value('ابتدا واحد اضافه کنید')->class('form-control border-danger text-danger')->disabled()); ?>

                                    <?php endif; ?>
                                    <?php $__errorArgs = ['Vahed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>

                            </tr>
                            <tr>
                                <th scope="col">توضیحات</th>
                                <td><?php echo e(html()->textarea('Details2')->class('form-control')->id('Details2')->placeholder('توضیحات')->style('resize:none;')); ?>

                                    <?php $__errorArgs = ['Details2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">نقطه سفارش کالا</th>
                                <td><?php echo e(html()->text('OrderDot')->class('form-control')->id('OrderDot')->placeholder('نقطه سفارش کالا')); ?>

                                    <?php $__errorArgs = ['OrderDot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">عکس محصول</th>
                                <td><?php echo e(html()->file('ProductImage')->name('ProductImage')->id('ProductImage')->class('form-control-file')); ?>

                                    <?php $__errorArgs = ['ProductImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <th scope="col">درصد شاخص</th>
                                <td><?php echo e(html()->text('Indicate')->class('form-control')->id("Indicate")->placeholder('درصد شاخص')); ?>

                                    <?php $__errorArgs = ['Indicate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></td>
                            </tr>
                            <tr>
                                <td>
                                    <?php if($Sorts->isnotempty() && $Vaheds->isnotempty() ): ?>
                                    <button type="submit" class="btn btn-success">اعمال</button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-success disabled">لطفا ابتدا مقادیر خواسته شده را اضافه کنید</button>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('Admin.Products.index')); ?>" class="btn btn-danger">بازگشت</a></td>
                            </tr>
                            </thead>
                        </table>
                        <?php echo e(html()->form()->close()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/FormProducts.blade.php ENDPATH**/ ?>