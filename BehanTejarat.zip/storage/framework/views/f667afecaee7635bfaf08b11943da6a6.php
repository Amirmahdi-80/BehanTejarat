<?php $__env->startSection($title,'title'); ?>
<?php $__env->startSection($about,'about'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-cost')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row no-gutters">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div
                        class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                        <img src="<?php echo e(asset('assets/images/Cost.png')); ?>" alt="هزینه های خودروها" class="img2">
                        <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                        <p><?php echo e($about); ?></p>
                    </div>
                    <!-- panel body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12">
                        <span class="d-flex row justify-content-center align-items-center">
                            <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2"><i
                                    class="material-icons">print</i></button>
                            <a href="<?php echo e(route('Admin.searchcost')); ?>" class="btn btn-info">جست و جو</a>
                        </span>
                        <span id="printdivcontent">
                        <table class="table text-center" dir="rtl">
                            <thead>
                            <a href="<?php echo e(route('Admin.cost.create')); ?>" class="btn btn-block btn-info">افزودن هزینه<i
                                    class="material-icons">add_circle_outline</i></a>
                            <tr>
                                <th scope="col">دسته هزینه</th>
                                <th scope="col">نام هزینه</th>
                                <th scope="col">تاریخ ثبت</th>
                                <th scope="col">قیمت کل</th>
                                <th scope="col">ویرایش</th>
                                <th scope="col">مشاهده جزئیات</th>
                                <th scope="col">حذف</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item -> Group); ?></td>
                                    <?php if(!($item->CarNam==null)): ?>
                                        <td><?php echo e($item -> CarNam); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($item -> HaNam); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($item -> date); ?></td>
                                    <td dir="rtl"><?php echo e(number_format($item -> PriceKol,0,".",",")); ?> ريال </td>
                                    <td><a href="<?php echo e(route('Admin.cost.edit', $item->id)); ?>" class="btn btn-warning">
                                            <i class="material-icons">edit</i>
                                        </a></td>
                                    <td><a href="<?php echo e(route('Admin.cost.show', $item->id)); ?>"
                                           class="btn btn-sm btn-info"><i
                                                class="material-icons">remove_red_eye</i></a></td>
                                    <td>
                                        <?php echo e(html()->form('DELETE', route('Admin.cost.destroy', $item->id))->open()); ?>

                                        <button class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                        <?php echo e(html()->form()->close()); ?>

                                    </td>
                                </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                            </span>
                        <span dir="ltr"><a href="<?php echo e($items->previousPageUrl()); ?>" class="btn btn-light"><i
                                    class="material-icons text-dark">arrow_back</i>
                                </a>
                                <?php for($i=1;$i<=$items->lastPage();$i++): ?>
                                <a href="<?php echo e($items->url($i)); ?>" class="btn btn-light page-item"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                                <a href="<?php echo e($items->nextPageUrl()); ?>" class="btn btn-light">
                                    <i class="material-icons text-dark">arrow_forward</i>
                                </a>
                            </span>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Cost/Cost.blade.php ENDPATH**/ ?>