<?php $__env->startSection($title,'title'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="flex-column d-flex overflow-auto mt-5 w-100">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- panel body -->
                    <div class="panel-body">
                        <?php echo csrf_field(); ?>
                            <?php echo e(html()->model($item)->form('POST', route('Admin.Indicator.store', $item->id))->open()); ?>

                        <div class="d-flex flex-column justify-content-center align-items-center w-100">
                            <table class="table text-right w-50" dir="rtl">
                                <tbody>
                                <tr>
                                    <th scope="col">نام محصول</th>
                                    <td>
                                        <?php echo e(html()->text('Product')->class('form-control')->value($item->PName)->isReadonly()); ?>

                                    </td>
                                    <?php $__errorArgs = ['Tamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                <tr>
                                    <th scope="col">تاریخ ثبت</th>
                                    <td><?php echo e(html()->text('date')->class('form-control date1')->id('date')->placeholder('تاریخ ثبت')->attribute('autocomplete="off"')); ?></td>
                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                <tr>
                                    <th scope="col">تامین کننده</th>
                                    <td>
                                        <?php echo e(html()->select('Tamin')->class('form-control')->open()); ?>

                                        <?php echo e(html()->option('-')->value('-')); ?>

                                        <?php $__currentLoopData = $Tamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tamin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(html()->option($tamin->TaminName)->value($tamin->TaminName)); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e(html()->select()->close()); ?>

                                    </td>
                                    <?php $__errorArgs = ['Tamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                <tr>
                                    <th scope="col">وزن کلی</th>
                                    <td><?php echo e(html()->text('VaznKol')->class('form-control')->id('VaznKol')->placeholder('وزن کلی')->attribute('autocomplete="off"')); ?></td>
                                    <?php $__errorArgs = ['VaznKol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <td>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    </td>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </tr>
                                </tbody>
                            </table>
                            <table class="table text-right table-borderless" dir="rtl">
                                <tbody>
                                <tr class="bg-info text-center">
                                    <th scope="col" class="text-light">ردیف</th>
                                    <th scope="col" class="text-light">نام محصول</th>
                                    <th scope="col" class="text-light">شناسه محصول</th>
                                    <th scope="col" class="text-light">تولید واقعی</th>
                                    <th scope="col" class="text-light">واحد</th>
                                    <th scope="col" class="text-light">شاخص(درصد)</th>
                                    <th scope="col" class="text-light">درصدآنالیز</th>
                                    <th scope="col" class="text-light">انحراف</th>
                                </tr>
                                <tr class="text-center">
                                    
                                    <td scope="col">1</td>
                                    
                                    <td scope="col">
                                        <?php echo e(html()->text('Product1')->class('form-control')->value($item->ProName1)->isReadonly()); ?>

                                    </td>
                                    
                                    <td scope="col">
                                        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->ProName1 == $Product->ProductComment): ?>
                                            <?php if(!$Product->ProductId== ""): ?>
                                                    <?php echo e($Product->ProductId); ?>

                                                <?php else: ?>
                                                0
                                                <?php endif; ?>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td scope="col"><?php echo e(html()->text('Tol1')->class('form-control')->placeholder('تولید واقعی')->id('Tol1')->attribute('oninput="calculateAndPerformUpdates(1)"')->attribute('autocomplete="off"')); ?></td>
                                    <td scope="col"><?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->ProName1 == $Product->ProductComment): ?>
                                                <?php if(!$Product->Vahed == ""): ?>
                                                    <?php echo e($Product->Vahed); ?>

                                                <?php else: ?>
                                                    0
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                    <td scope="col">
                                        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->ProName1 == $Product->ProductComment): ?>
                                                <?php if(!$Product->Indicate == ""): ?>
                                                    <?php echo e(html()->text()->class('form-control')->placeholder('شاخص')->id('Ind1')->isReadonly()->value($Product->Indicate)); ?>

                                                <?php else: ?>
                                                    <?php echo e(html()->text()->class('form-control')->placeholder('شاخص')->id('Ind1')->isReadonly()->value(0)); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td scope="col"><?php echo e(html()->text('Analyse1')->class('form-control')->placeholder('درصد آنالیز')->id('Anz1')->isReadonly()->value('')); ?></td>
                                    <td scope="col"><?php echo e(html()->text('Deviation1')->class('form-control')->placeholder('درصد انحراف')->id('Dev1')->isReadonly()->value('')); ?></td>
                                </tr>
                                <?php for($i = 2; $i <= 20; $i++): ?>
                                    <?php if(!$item->{"ProName$i"} == ""): ?>
                                        <tr class="text-center">
                                            
                                            <td scope="col"><?php echo e($i); ?></td>
                                            
                                            <td scope="col">
                                                <?php echo e(html()->text("Product$i")->class('form-control')->value($item->{"ProName$i"})->isReadonly()); ?>

                                            </td>
                                            
                                            <td scope="col">
                                                <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->{"ProName$i"} == $Product->ProductComment): ?>
                                                        <?php if(!$Product->ProductId== ""): ?>
                                                            <?php echo e($Product->ProductId); ?>

                                                        <?php else: ?>
                                                            0
                                                        <?php endif; ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td scope="col"><?php echo e(html()->text("Tol$i")->class('form-control')->placeholder('تولید واقعی')->id("Tol$i")->attribute("oninput='calculateAndPerformUpdates($i)'")->attribute('autocomplete="off"')); ?></td>
                                            <td scope="col"><?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->{"ProName$i"} == $Product->ProductComment): ?>
                                                        <?php if(!$Product->Vahed == ""): ?>
                                                            <?php echo e($Product->Vahed); ?>

                                                        <?php else: ?>
                                                            0
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                            <td scope="col">
                                                <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->{"ProName$i"} == $Product->ProductComment): ?>
                                                        <?php if(!$Product->Indicate == ""): ?>
                                                            <?php echo e(html()->text()->class('form-control')->placeholder('شاخص')->id("Ind$i")->isReadonly()->value($Product->Indicate)); ?>

                                                        <?php else: ?>
                                                            <?php echo e(html()->text()->class('form-control')->placeholder('شاخص')->id("Ind$i")->isReadonly()->value(0)); ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td scope="col"><?php echo e(html()->text("Analyse$i")->class('form-control')->placeholder('درصد آنالیز')->id("Anz$i")->isReadonly()->value('')); ?></td>
                                            <td scope="col"><?php echo e(html()->text("Deviation$i")->class('form-control')->placeholder('درصد انحراف')->id("Dev$i")->isReadonly()->value('')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                    <tr class="text-center">
                                        
                                        <td scope="col" colspan="3">مجموع:</td>
                                        
                                        <td scope="col">
                                            <?php echo e(html()->text('TolKol')->class('form-control')->value("")->placeholder("مجموع تولید واقعی")->id("TolKol")->isReadonly()); ?>

                                        </td>
                                        
                                        <td scope="col">
                                            -
                                        </td>
                                        <td scope="col"><?php echo e(html()->text('ShKol')->class('form-control')->placeholder('مجموع شاخص')->id('ShKol')->isReadonly()); ?></td>
                                        <td scope="col"><?php echo e(html()->text('AnzKol')->class('form-control')->placeholder('مجموع آنالیز')->id('AnzKol')->isReadonly()); ?></td>
                                        <td scope="col">
                                            <?php echo e(html()->text('EnherafKol')->class('form-control')->placeholder('مجموع انحراف')->id('EnherafKol')->isReadonly()); ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <span class="d-flex row justify-content-center align-items-center" style="gap: 20px">
                                <button type="submit" class="btn btn-success">ثبت</button>
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger">بازگشت</a>
                            </span>
                        </div>
                        <?php echo e(html()->form()->close()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/IndicatorAdd.blade.php ENDPATH**/ ?>