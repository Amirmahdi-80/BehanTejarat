<?php $__env->startSection($title,'title'); ?>
<?php $__env->startSection($about,'about'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cars')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="container-fluid p-0">
            <div class="panel panel-primary">
                <div
                    class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                    <img src="<?php echo e(asset('assets/images/Cars.png')); ?>" alt="خودروها" class="img2">
                    <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                    <p><?php echo e($about); ?></p>
                    <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info m-2"><i
                            class="material-icons">print</i></button>
                </div>
                <!-- panel body -->
                <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12">
                    <div class="table-responsive" id="printdivcontent">
                        <table class="table text-center table-responsive" dir="rtl">
                            <thead>
                            <a href="<?php echo e(route('Admin.Cars.create')); ?>" class="btn btn-block btn-info">افزودن خودرو<i
                                    class="material-icons">add_circle_outline</i></a>
                            <tr>
                                <th scope="col">نام خودرو</th>
                                <th scope="col" class="text-right">شماره پلاک</th>
                                <th scope="col">رنگ خودرو</th>
                                <th scope="col">کارکرد</th>
                                <th scope="col">بیمه شخص ثالث</th>
                                <th scope="col">کارت خودرو</th>
                                <th scope="col">برگه سبز</th>
                                <th scope="col">بیمه بدنه</th>
                                <th scope="col">عکس خودرو</th>
                                <th scope="col">ویرایش</th>
                                <th scope="col">حذف</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item -> CarName); ?></td>
                                    <td><?php echo e($item -> CarPlate); ?></td>
                                    <td><?php echo e($item -> CarColor); ?></td>
                                    <td dir="ltr"><?php echo e(number_format($item -> Kilometer,0,".",",")); ?> Km</td>
                                    <td data-toggle="tooltip" data-placement="bottom"
                                        title="برای دانلود عکس کلیک کنید"><?php if(!$item->BimeSales==""): ?>
                                            <a href="<?php echo e(route("files.show", $item->BimeSales)); ?>"><img
                                                    class="avatar img-circle"
                                                    src="<?php echo e(route("files.show", $item->BimeSales)); ?>"
                                                    alt="عکس بیمه شخص ثالث" title="عکس بیمه شخص ثالث"
                                                    style="border-radius: 5px;width: 50px;
                                                               height: 50px;"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?></td>
                                    <td data-toggle="tooltip" data-placement="bottom"
                                        title="برای دانلود عکس کلیک کنید"><?php if(!$item->CarCard==""): ?>
                                            <a href="<?php echo e(route("files.show", $item->CarCard)); ?>"><img
                                                    class="avatar img-circle"
                                                    src="<?php echo e(route("files.show", $item->CarCard)); ?>"
                                                    alt="عکس کارت خودرو" title="عکس کارت خودرو"
                                                    style="border-radius: 5px;width: 50px;
                                                               height: 50px;"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?></td>
                                    <td data-toggle="tooltip" data-placement="bottom"
                                        title="برای دانلود عکس کلیک کنید"><?php if(!$item->BargSabz==""): ?>
                                            <a href="<?php echo e(route("files.show", $item->BargSabz)); ?>"><img
                                                    class="avatar img-circle"
                                                    src="<?php echo e(route("files.show", $item->BargSabz)); ?>"
                                                    alt="عکس برگ سبز خودرو" title="عکس برگ سبز خودرو"
                                                    style="border-radius: 5px;width: 50px;
                                                               height: 50px;"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?></td>
                                    <td data-toggle="tooltip" data-placement="bottom"
                                        title="برای دانلود عکس کلیک کنید"><?php if(!$item->Badane==""): ?>
                                            <a href="<?php echo e(route("files.show", $item->Badane)); ?>"><img
                                                    class="avatar img-circle"
                                                    src="<?php echo e(route("files.show", $item->Badane)); ?>"
                                                    alt="عکس بیمه بدنه خودرو" title="عکس بیمه بدنه خودرو"
                                                    style="border-radius: 5px;width: 50px;
                                                               height: 50px;"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?></td>
                                    <td data-toggle="tooltip" data-placement="bottom"
                                        title="برای دانلود عکس کلیک کنید">
                                        <?php if(!$item->image==""): ?>
                                            <a href="<?php echo e(route("files.show", $item->image)); ?>"><img
                                                    class="avatar img-circle"
                                                    src="<?php echo e(route("files.show", $item->image)); ?>"
                                                    alt="عکس خودرو" title="عکس  خودرو"
                                                    style="border-radius: 5px;width: 50px;
                                                               height: 50px;"></a>
                                        <?php else: ?>
                                            <span>خالی</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('Admin.Cars.edit', $item->id)); ?>" class="btn btn-warning">
                                            <i class="material-icons">edit</i>
                                        </a></td>
                                    <td>
                                        <?php echo e(html()->form('DELETE', route('Admin.Cars.destroy', $item->id))->open()); ?>

                                        <button class="btn btn-danger">
                                            <i class="material-icons">delete</i>
                                        </button>
                                        <?php echo e(html()->form()->close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <span dir="ltr" class="w-100 d-flex row justify-content-center align-items-center" style="gap: 10px"><a
                    href="<?php echo e($items->previousPageUrl()); ?>" class="btn btn-light"><i class="material-icons text-dark">arrow_back</i>
                                </a>
                                <?php for($i=1;$i<=$items->lastPage();$i++): ?>
                    <a href="<?php echo e($items->url($i)); ?>" class="btn btn-light page-item"><?php echo e($i); ?></a>
                <?php endfor; ?>
                                <a href="<?php echo e($items->nextPageUrl()); ?>" class="btn btn-light">
                                    <i class="material-icons text-dark">arrow_forward</i>
                                </a>
                            </span>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Cars/Cars.blade.php ENDPATH**/ ?>