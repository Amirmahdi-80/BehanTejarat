<?php if(\Illuminate\Support\Facades\Auth::check()): ?>
    <!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="description"
          content="وب اپلیکیشن ,شرکت, بهان تجارت,شرکت بهان تجارت , در , زمینه رستوران , داری به مدیریت امیر حسین فلاحی فعالیت دارد،طراحی و توسعه یافته توسط ,امیرمهدی اسدی">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="امیر حسین فلاحی,امیرمهدی اسدی , وب اپلیکیشن ,بهان تجارت ,رستوران,شرکت">
    <meta name="copyright" content="امیرمهدی اسدی | امیر حسین فلاحی">
    <meta name="robots" content="index, follow"/>
    <meta name="Classification" content="بیزینس"/>
    <meta name="author" content="Amirmahdi Asadi, pgamirmahdi@gmail.com"/>
    <meta name="designer" content="امیرمهدی اسدی"/>
    <meta name="owner" content="امیر حسین فلاحی | امیرمهدی اسدی"/>
    <meta name="rating" content="General"/>
    <meta property="og:type" content="website">
    <meta property="og:title" content="وب اپلیکیشن بهان تجارت">
    <meta property="og:description"
          content="وب اپلیکیشن شرکت بهان تجارت,شرکت بهان تجارت  در  زمینه رستوران  داری به مدیریت امیر حسین فلاحی فعالیت دارد،طراحی و توسعه یافته توسط امیرمهدی اسدی">
    <meta property="og:site_name" content="وب اپلیکیشن بهان تجارت آفرین">
    <meta property="og:image" content=”<?php echo e(asset('assets/images/screenshots/Screenshot3.png')); ?>”/>
    <meta property="og:locale" content="fa_IR">
    <meta name="theme-color" content="#0ebfff">
    <meta property="og:url" content="https://behantejaratco.ir">
    <meta name="google-site-verification" content="ZctxTrSondLmcLgfS3t9GIP4J8M1DSt0cJYl41xlwJg"/>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/Home.css?v=version2')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" type="image/x-icon">
    
    <link rel="manifest" href="<?php echo e(asset('assets/manifest.json')); ?>"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/Logo.png')); ?>"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/Logo72.png')); ?>"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/Logo144.png')); ?>"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/Logo196.png')); ?>"/>
    <link rel="canonical" href="https://behantejaratco.ir/">
    <meta name="apple-mobile-web-app-status-bar" content="#aa7700">
    <script src="<?php echo e(asset('assets/js/appl2.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/jquery-3.4.1.slim.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>" defer></script>
    <script defer>if ("serviceWorker" in navigator) {
            navigator.serviceWorker
                .register("<?php echo e(asset('assets/serviceWorker.js')); ?>")
                .then(reg => {
                    console.log("Service worker registred successfully", reg);
                })
                .catch(err => {
                    console.log("service worker not registred !!", err);
                });
        }
    </script>
    <script type="application/ld+json" defer>
{
  "@context": "http://schema.org",
  "@type": "LocalBusiness",
  "name": "بهان تجارت آفرین",
  "image": "https://behantejaratco.ir/assets/images/Logo.png",
  "telephone": "09336533433",
  "email": "",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "خیابان وطن پور شمالی",
    "addressLocality": "تهران"
  }
}


    </script>

</head>
<body onload="load()" id="body" class="no-gutters overflow-x-hidden">
<div class="loade text-light" dir="rtl" id="loade">
    <div class="loader mb-3"></div>
    در حال بارگذاری...
</div>

<div class="head2 d-flex justify-content-between align-items-center row" style="height: 60px !important;" dir="rtl">
    <span class="d-flex justify-content-center align-items-center" style="height: 60px;width: fit-content"><a
            href="<?php echo e(route('Home.index')); ?>"
            class="d-flex justify-content-center align-items-center flex-column A2 w-100"><img
                src="<?php echo e(asset('assets/images/Logo.png')); ?>" alt="Brand" class="No8"></a></span>
    
    
    
    <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
        <span class="d-flex row justify-content-center align-items-center A1 h-100"
              style="width: fit-content !important;gap: 10px;margin-left: 5px !important;">
                <?php if(auth()->user()->avatar  == ""): ?>
                <img src="<?php echo e(asset('assets/images/Report.png')); ?>" alt="گزارش" class="No8"
                     onclick="window.open('tel:09336533433');">
                <a href="<?php echo e(route('Admin.dashboard')); ?>" class="p-0 m-0"><img src="<?php echo e(asset('assets/images/Sign-up.png')); ?>"
                                                                            alt="عکس پروفایل" class="No8"></a>
            <?php else: ?>
                <img src="<?php echo e(asset('assets/images/Report.png')); ?>" alt="گزارش" class="No8"
                     onclick="window.open('tel:09336533433');">
                <a href="<?php echo e(route('Admin.dashboard')); ?>" class="p-0 m-0"><img
                        src="<?php echo e(auth()->user()->avatar ? route('showAvatar', [auth()->user()->avatar]) : ''); ?>"
                        alt="ProfilePic" style="border-radius: 50px" class="No8"></a>
            <?php endif; ?>
            <?php else: ?>
                <span class="row justify-content-center align-items-center m-2" style="width: fit-content;height: 60px"><a
                        href="<?php echo e(route('signup.view')); ?>" class="btn btn-outline-info">ورود/ثبت نام</a></span>
            </span>
    <?php endif; ?>
</div>
<div class="head3">
    <ul class="w-100 d-flex row justify-content-around align-items-center m-0 p-0 h-100 w-100" style="gap: 10px">
        <a href="<?php echo e(route('HomeApp')); ?>">
            <li id="li">
                <i class="material-icons">business</i>
                <span>خانه</span>
            </li>
        </a>
        <a href="<?php echo e(route('Home.index')); ?>">
            <li>
                <i class="material-icons">add_to_queue</i>
                <span>سایت</span>
            </li>
        </a>
        <a href="<?php echo e(route('Admin.dashboard')); ?>">
            <li>
                <i class="material-icons">laptop</i>
                <span>پنل</span>
            </li>
        </a>
    </ul>
</div>

<div class="body bs">
    <div style="width: 85%;margin: 10px 0px" class="lo1"><img src="<?php echo e(asset('assets/images/Banner.jpg')); ?>"
                                                              alt="رمضان مبارک" class="w-100"
                                                              style="border-radius: 15px"></div>

    <ul class="ITem my-4">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
        <a href="<?php echo e(route('Admin.Initialize.index')); ?>">
        <li>
            <img src="<?php echo e(asset('assets/images/Vahed.png')); ?>" alt="واحد ها">
            <span>واحد ها</span>
        </li>
        </a>
        <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
        <a href="<?php echo e(route('Admin.Sort.index')); ?>">
        <li>
            <img src="<?php echo e(asset('assets/images/Sort.png')); ?>" alt="دسته بندی ها">
            <span>دسته بندی ها</span>
        </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
        <a href="<?php echo e(route("Admin.Tamin.index")); ?>">
        <li>
            <img src="<?php echo e(asset('assets/images/Tamin.png')); ?>" alt="تامین کنندگان">
            <span>تامین کنندگان</span>
        </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
        <a href="<?php echo e(route("Admin.Vorud.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Provider.png')); ?>" alt="ورودی ها">
                <span>ورودی ها</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
                <a href="<?php echo e(route("Admin.Out.index")); ?>">
                    <li>
                        <img src="<?php echo e(asset('assets/images/Out.png')); ?>" alt="حواله ها">
                        <span>حواله ها</span>
                    </li>
                </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
        <a href="<?php echo e(route("Admin.Links.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Links.png')); ?>" alt="تشکیل ساختار">
                <span>تشکیل ساختار</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
        <a href="<?php echo e(route("Admin.Indicator.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Indicator.png')); ?>" alt="َشاخص سازی">
                <span>شاخص  سازی</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Cars')): ?>
        <a href="<?php echo e(route("Admin.Driver.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Driver.png')); ?>" alt="راننده ها">
                <span>راننده ها</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-cost')): ?>
        <a href="<?php echo e(route("Admin.cost.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Cost.png')); ?>" alt="هزینه ها">
                <span>هزینه ها</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-cost')): ?>
        <a href="<?php echo e(route("Admin.costSort.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/SortCost.png')); ?>" alt="دسته هزینه">
                <span>دسته هزینه</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Soal')): ?>
        <a href="<?php echo e(route("Admin.Soal.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Soal.png')); ?>" alt="سوالات متداول">
                <span>سوالات متداول</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('TrueLock')): ?>
        <a href="<?php echo e(route("Admin.Favorite.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Favorite.png')); ?>" alt="علاقه مندی هام">
                <span>علاقه مندی هام</span>
            </li>
        </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-orders')): ?>
        <a href="<?php echo e(route("Admin.Orders.index")); ?>">
            <li>
                <img src="<?php echo e(asset('assets/images/Orders.png')); ?>" alt="سفارشات">
                <span>سفارشات</span>
            </li>
        </a>
            <?php endif; ?>
    </ul>
    <div class="mune">
        <ul>
            <a href="<?php echo e(route('Admin.Products.index')); ?>">
                <li>
                    <img src="<?php echo e(asset('assets/images/EditUsers.png')); ?>" alt="محصولات">
                    <span>محصولات</span>
                </li>
            </a>
            <a href="<?php echo e(route("Admin.Cars.index")); ?>">
                <li>
                    <img src="<?php echo e(asset('assets/images/Cars.png')); ?>" alt="خودروها">
                    <span>خودرو ها</span>
                </li>
            </a>
            <a href="<?php echo e(route("Admin.Editusers.index")); ?>">
                <li>
                    <img src="<?php echo e(asset('assets/images/EditUser.png')); ?>" alt="کاربران">
                    <span>کاربران</span>
                </li>
            </a>
            <a href="<?php echo e(route("Admin.Slider.index")); ?>">
                <li>
                    <img src="<?php echo e(asset('assets/images/Slider.png')); ?>" alt="اسلایدشو">
                    <span>اسلایدشو</span>
                </li>
            </a>
        </ul>
    </div>
    <div id="carouselExampleAutoplaying" class="carousel slide mt-4" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo e(asset('assets/images/App.jpg')); ?>" class="d-block w-100" alt="بهان تجارت" title="بهان تجارت">
            </div>
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$slide->image==''): ?>
                    <div class="carousel-item">
                        <img src="<?php echo e(route("files.show", $slide->image)); ?>" class="d-block w-100 ak"
                             alt="<?php echo e($slide->SlideTozih); ?>" title="<?php echo e($slide->SlideTozih); ?>">
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev slide2" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">قبلی</span>
        </button>
        <button class="carousel-control-next slide2" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">بعدی</span>
        </button>
    </div>
</div>
<!-- Designed and Engineered by Amirmahdi Asadi :D -->
</body>
</html>
<?php else: ?>
    <script>
        setTimeout(() => {
            location.href = "/login";
        }, 0);
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/HomeApp.blade.php ENDPATH**/ ?>