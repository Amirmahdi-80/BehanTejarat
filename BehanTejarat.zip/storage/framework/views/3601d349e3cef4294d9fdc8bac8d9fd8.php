<?php $__env->startSection($title,'title'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <div class="row no-gutters">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <!-- panel body -->
                    <div class="panel-body d-flex flex-column justify-content-center align-items-center col-12">
                        <button type="button" onclick="PrintDiv();" value="Print" class="btn btn-info mt-5"><i
                                class="material-icons">print</i></button>
                        <div
                            class="panel-body d-flex flex-column justify-content-center align-items-center w-100 overflow-auto"
                            id="printdivcontent">
                            <span class="dn"><?php $__currentLoopData = $Vorud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vorud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($i += $vorud->enterPrice,0); ?> ريال
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                            <span class="dn"><?php $__currentLoopData = $Vorud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vorud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($j += $vorud->Count,0); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                            <span class="dn"><?php $__currentLoopData = $Vorud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vorud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($k += $vorud->TotalPrice,0); ?> ريال
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                            <table class="table text-center mt-2" dir="rtl" onloadstart="load3()">
                                <thead>
                                <tr>
                                    <th colspan="6" class="bg-info"> ریز جزئیات ورود
                                        محصول <?php echo e($item->ProductComment); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="col">نام تامین کننده</th>
                                    <th scope="col">تاریخ ورود محصول</th>
                                    <th scope="col">مبلغ</th>
                                    <th scope="col">مقدار</th>
                                    <th scope="col">مبلغ کل</th>
                                    <th scope="col">ریز جزئیات</th>
                                </tr>
                                <?php $__currentLoopData = $Vorud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vorud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($vorud -> TName); ?></td>
                                        <td><?php echo e($vorud -> date); ?></td>
                                        <td dir="rtl" class="mab"><?php echo e(number_format($vorud -> enterPrice,0,".",",")); ?>

                                            ريال
                                        </td>
                                        <td dir="rtl" class="meq"><?php echo e(number_format($vorud -> Count,0,".",",")); ?></td>
                                        <td dir="rtl" class="mabkol"><?php echo e(number_format($vorud -> TotalPrice,0,".",",")); ?>

                                            ريال
                                        </td>
                                        <td><a href="<?php echo e(route('Admin.Vorud.show', $vorud->id)); ?>" class="btn btn-info">
                                                <i class="material-icons">remove_red_eye</i>
                                            </a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="2"><a href="<?php echo e(route('Admin.Products.index')); ?>"
                                                       class="btn btn-danger btn-block mb-2">بازگشت</a></td>
                                    <td>جمع مبلغ: <?php echo e(number_format($i,0,".",",")); ?> ريال</td>
                                    <td>جمع مقدار: <?php echo e(number_format($j)); ?></td>
                                    <td>جمع مبلغ کل: <?php echo e(number_format($k,0,".",",")); ?> ريال</td>
                                    <td>بهان تجارت آفرین</td>
                                </tr>
                                </tbody>
                            </table>
                            <span class="dn"><?php $__currentLoopData = $Out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $out): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($i2 += $out->exitPrice,0); ?> ريال
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                            <span class="dn"><?php $__currentLoopData = $Out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $out): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($j2 += $out->Count,0); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                            <span class="dn"><?php $__currentLoopData = $Out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $out): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($k2 += $out->TotalPrice,0); ?> ريال
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                            <table class="table text-center mt-2" dir="rtl">
                                <thead>
                                <tr>
                                    <th colspan="6" class="bg-info"> ریز جزئیات خروج
                                        محصول <?php echo e($item->ProductComment); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope="col">نام تامین کننده</th>
                                    <th scope="col">تاریخ خروج محصول</th>
                                    <th scope="col">مبلغ</th>
                                    <th scope="col">مقدار</th>
                                    <th scope="col">مبلغ کل</th>
                                    <th scope="col">ریز جزئیات</th>
                                </tr>
                                <?php $__currentLoopData = $Out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $out): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($out -> TName); ?></td>
                                        <td><?php echo e($out -> date); ?></td>
                                        <td dir="rtl" class="mab"><?php echo e(number_format($out -> exitPrice,0,".",",")); ?>

                                            ريال
                                        </td>
                                        <td dir="rtl" class="meq"><?php echo e(number_format($out -> Count,0,".",",")); ?></td>
                                        <td dir="rtl" class="mabkol"><?php echo e(number_format($out -> TotalPrice,0,".",",")); ?>

                                            ريال
                                        </td>
                                        <td><a href="<?php echo e(route('Admin.Vorud.show', $out->id)); ?>" class="btn btn-info">
                                                <i class="material-icons">remove_red_eye</i>
                                            </a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="2"><a href="<?php echo e(route('Admin.Products.index')); ?>"
                                                       class="btn btn-danger btn-block mb-2">بازگشت</a></td>
                                    <td>جمع مبلغ: <?php echo e(number_format($i2,0,".",",")); ?> ريال</td>
                                    <td>جمع مقدار: <?php echo e(number_format($j2)); ?></td>
                                    <td>جمع مبلغ کل: <?php echo e(number_format($k2,0,".",",")); ?> ريال</td>
                                    <td>بهان تجارت آفرین</td>
                                </tr>
                                </tbody>
                            </table>
                            <table class="table text-center">
                                <tr>
                                    <td colspan="2" class="bg-info">جزئیات انبار</td>
                                </tr>
                                <tr class="bg-info">
                                    <th>
                                        مبلغ انبار
                                    </th>
                                    <th>
                                        مقدار باقی مانده در انبار
                                    </th>
                                </tr>
                                <tr>
                                    <td>
                                        <?php if(isset($out) && isset($vorud)): ?>
                                            <?php echo e(number_format(($out->TotalPrice - $vorud->TotalPrice), 0, ".", ",")); ?> ريال
                                        <?php elseif(isset($vorud) && !isset($out)): ?>
                                            <?php echo e(number_format($vorud->TotalPrice, 0, ".", ",")); ?> ريال
                                        <?php elseif(isset($out) && !isset($vorud)): ?>
                                            <?php echo e(number_format($out->TotalPrice, 0, ".", ",")); ?> ريال
                                        <?php else: ?>
                                            خالی
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(isset($out) && isset($vorud)): ?>
                                            <?php echo e(number_format(($vorud->Count - $out->Count), 0, ".", ",")); ?>

                                        <?php elseif(isset($vorud) && !isset($out)): ?>
                                            <?php echo e(number_format($vorud->Count, 0, ".", ",")); ?>

                                        <?php elseif(isset($out) && !isset($vorud)): ?>
                                            <?php echo e(number_format($out->Count, 0, ".", ",")); ?>

                                        <?php else: ?>
                                            خالی
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/ProductDetail.blade.php ENDPATH**/ ?>