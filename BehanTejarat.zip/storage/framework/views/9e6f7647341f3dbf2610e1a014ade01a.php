<?php $__env->startSection($title,'title'); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-products')): ?>
    <?php $__env->startSection('ZPanel'); ?>
        <!-- Panel Header -->
        <div class="container-fluid p-0">
            <div class="panel panel-primary w-100">
                <div class="panel-heading clearfix mb-4 d-flex flex-column justify-content-center align-items-center">
                    <img src="<?php echo e(asset('assets/images/Links.png')); ?>" alt="ویرایش لینک ها" class="img2">
                    <h1 class="panel-title text-dark text-center mb-5 mt-2"><?php echo e($title); ?></h1>
                    <p>شما در این صفحه میتوانید محصولات را لینک سازی و یا لینک آنهارا حذف کنید. بدین منظور از دکمه
                        های درون جدول
                        استفاده کنید.</p>
                </div>

                <!-- Search Form -->
                <span class="d-flex flex-column justify-content-center align-items-center">
                    <label style="border-bottom: 2px dashed gray;width: 30%;color: #333" class="text-center pb-2">فیلتر بر اساس جست و جو</label>
                    <form action="<?php echo e(route('Admin.searchLink')); ?>" method="GET" class="text-dark d-flex row justify-content-center align-items-center mb-4 search no-gutters">
                        <input type="text" name="search" class="text-dark" placeholder="جست و جو کنید">
                        <button type="submit"><i class="material-icons">search</i></button>
                    </form>
                </span>

                <!-- Panel Body -->
                <div class="panel-body d-flex flex-column justify-content-center align-items-center">
                    <div class="table-responsive">
                        <table class="table text-center table-responsive" dir="rtl">
                            <thead>
                            <a href="<?php echo e(route('Admin.Links.create')); ?>" class="btn btn-block btn-info">لینک سازی<i class="material-icons">add_circle_outline</i></a>
                            <tr>
                                <th scope="col">تاریخ ثبت</th>
                                <th scope="col">نام محصول</th>
                                <th scope="col">زیر مجموعه اول</th>
                                <th scope="col">زیر مجموعه دوم</th>
                                <th scope="col">زیر مجموعه سوم</th>
                                <th scope="col">بیشتر</th>
                                <th scope="col">ویرایش</th>
                                <th scope="col">حذف</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($item->date); ?></td>
                                    <td><?php echo e($item->PName); ?></td>
                                    <td><?php echo e($item->ProName1); ?></td>
                                    <td><?php if(!$item->ProName2 == ""): ?> <?php echo e($item->ProName2); ?> <?php else: ?> خالی <?php endif; ?></td>
                                    <td><?php if(!$item->ProName3 == ""): ?> <?php echo e($item->ProName3); ?> <?php else: ?> خالی <?php endif; ?></td>
                                    <td><a href="<?php echo e(route('Admin.Links.show', $item->id)); ?>" class="btn btn-info"><i class="material-icons">visibility</i></a></td>
                                    <td><a href="<?php echo e(route('Admin.Links.edit', $item->id)); ?>" class="btn btn-warning"><i class="material-icons">edit</i></a></td>
                                    <td>
                                        <?php echo e(html()->form('DELETE', route('Admin.Links.destroy', $item->id))->open()); ?>

                                        <button class="btn btn-danger <?php if($item->Storage <= $item->OrderDot & !$item->Storage == ""): ?> btn-dark <?php endif; ?>"><i class="material-icons">delete</i></button>
                                        <?php echo e(html()->form()->close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <span dir="ltr">
                        <a href="<?php echo e($items->previousPageUrl()); ?>" class="btn btn-light"><i class="material-icons text-dark">arrow_back</i></a>
                        <?php for($i=1;$i<=$items->lastPage();$i++): ?>
                            <a href="<?php echo e($items->url($i)); ?>" class="btn btn-light page-item"><?php echo e($i); ?></a>
                        <?php endfor; ?>
                        <a href="<?php echo e($items->nextPageUrl()); ?>" class="btn btn-light"><i class="material-icons text-dark">arrow_forward</i></a>
                    </span>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.Panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Products/Links.blade.php ENDPATH**/ ?>