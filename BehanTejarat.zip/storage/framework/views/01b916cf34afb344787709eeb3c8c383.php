<?php $__env->startSection('content'); ?>
        <body>
        <img src="<?php echo e(asset('assets/images/Logo.png')); ?>" alt="Logo" style="position: fixed;top: 0px;right: 10px">
        <div class="context">
        <div class="session">
            <img class="left" src="<?php echo e(asset('assets/images/Email.jpg')); ?>" alt="Register">
            <div class="No1">
                <form action="<?php echo e(route('signup.register')); ?>" method="POST" enctype="multipart/form-data" class="w-100">
                    <?php echo csrf_field(); ?>
                    <h4 class="text-center w-100">تایید ایمیل</h4>
                    <p class="w-100 text-center">کاربر <?php echo e(auth()->user()->Firstname); ?> <?php echo e(auth()->user()->Lastname); ?> جهت ورود به اکانت خود ایمیل ارسال شده به آدرس ایمیل خود را تایید کنید</p>
                    <span class="d-flex row justify-content-center align-items-center w-100 mr-0" style="gap: 5px">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-success">بررسی ورود</a>
                <a href="<?php echo e(route('logout')); ?>"  class="btn btn-danger">خروج</a>
            </span>
                </form>
                <span class="No2">
                    <?php if(session('status') == 'verification-link-sent'): ?>
                        <span class="mb-3 alert  alert-success" style="font-size: 12px">
                                        ایمیل جدید ارسال شد، لطفا مجددا بررسی کنید.
                                    </span>
                    <?php endif; ?>
                <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-dark m-2" type="submit">ایمیلی دریافت نکردید؟ برای دریافت مجدد اینجا کلیک کنید.</button></form></span>
            </div>
        </div>
        </div>
        <div class="area" >
            <ul class="circles">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div >
        </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Auth.LinkAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BehanTejarat\resources\views/Auth/verify-email.blade.php ENDPATH**/ ?>