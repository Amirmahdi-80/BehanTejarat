function load2(){
    const body=document.getElementById("body")
    body.getElementsByClassName('session')[0].classList.add('load')
    body.getElementsByClassName('No1')[0].classList.add('load')
}
